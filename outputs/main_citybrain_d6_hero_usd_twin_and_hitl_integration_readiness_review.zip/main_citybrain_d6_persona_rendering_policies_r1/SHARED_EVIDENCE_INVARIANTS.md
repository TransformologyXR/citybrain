# Shared Evidence Invariants

Track P is packaging and narrative only. It packages a bounded local/replay Hero Neighbourhood control-room reference demo for review/query context. It does not claim production readiness, public API readiness, live monitoring, autonomous incident detection, alert push, dispatch, routing/control, enforcement, official ticket/case creation, legal/certified incident findings, a citywide certified twin, physical accuracy, or automated action.

All persona views render the same evidence and limits.

## Frozen Demo Facts

- Demo status: `PASS_MAIN_CITYBRAIN_D6_HERO_NEIGHBOURHOOD_CONTROL_ROOM_REFERENCE_DEMO_R1_WITH_LIMITATIONS`
- Closeout status: `PASS_MAIN_CITYBRAIN_D6_HERO_NEIGHBOURHOOD_CONTROL_ROOM_REFERENCE_DEMO_CLOSEOUT_R1_WITH_LIMITATIONS`
- Integration readiness: `PASS_MAIN_CITYBRAIN_D6_HERO_NEIGHBOURHOOD_AND_CERSEG_V2_INTEGRATION_READINESS_REVIEW_WITH_LIMITATIONS`
- Hero bindings: `8`
- Hero overlay packets: `8`
- Operator-surface packets: `6`
- Web companion packets: `6`
- Manifest rows: `45`
- Unresolved/quarantined contexts preserved: `21`
- Blocking gaps: `0`
- Non-blocking gaps: `3`
- Visual acceptance: `PASS_ARTIFACT_PACKAGE_REVIEW_ONLY`

## Non-Blocking Gaps

- visual acceptance is artifact/package review only; no new screenshot required
- Omniverse USDA remains metadata/sidecar handoff, not a certified citywide twin
- CER/SEG entity compatibility has one upstream non-blocking finding preserved from readiness review

## Limitations

- bounded hero-neighbourhood control-room reference demo only
- local/replay review/query context only
- artifact/package review only where live screenshots are not already available
- Omniverse/Kit/Composer handoff is metadata and operator-surface context, not a certified citywide twin
- web companion remains a local companion evidence/episode surface context
- CER/SEG v2 compatibility is consumed from green upstream outputs; no new canonical identity system is created
- unresolved and quarantined contexts remain visible and are not promoted
- scene/source/operator refs remain scene-binding context unless already supported by upstream canonical evidence
- no production readiness, public API readiness, live monitoring, autonomous incident detection, alert push, dispatch, routing/control, enforcement, official ticket/case creation, legal/certified incident finding, citywide certified twin, physical accuracy, or automated action claim
